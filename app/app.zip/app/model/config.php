<?php

$db_host = 'localhost';
$db_name = 'admin_causeffect';
$db_user = 'admin_causeffect';
$db_pass = 'Xxi8q%14';

sql::$con = new mysqli($db_host, $db_user, $db_pass, $db_name);

class sql {

    public static $con;

}

if (!sql::$con->set_charset("utf8")) {

  printf("Error loading character set utf8: %s\n", sql::$con->error);
  exit();

}

?>
