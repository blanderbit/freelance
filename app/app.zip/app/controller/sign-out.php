<?php

$user->sign_out();

header('Location: /sign-in');

?>
