<div class="user-menu">

  <div class="name"><?php echo $_SESSION['user_firstname'] . ' ' . $_SESSION['user_lastname']; ?></div>

  <div class="menu-dropdown">

    <div class="menu-items">

      <a href="">Instellingen</a>
      <a href="/sign-out">Uitloggen</a>

    </div>

  </div>

</div>
